# ᝰ.ᐟ pharos

Tool được phát triển bởi nhóm tele Airdrop Hunter Siêu Tốc (https://t.me/airdrophuntersieutoc)

Link: [https://testnet.pharosnetwork.xyz/experience](https://testnet.pharosnetwork.xyz/experience?inviteCode=bQ5rxh4Jo3ES2EkC)

## 🚨 Attention Before Running R2 Cli Version

I am not `responsible` for the possibility of an account being `banned`!

## 📎 R2 Node cli version Script features

- Auto send
- Auto faucet
- Auto swap
- Auto add liquidity
- Auto reff
- Auto checkin
- Support proxy or not
- Mutiple threads, multiple accounts

## ✎ᝰ. RUNNING

- Clone Repository

```bash
git clone https://github.com/Hunga9k50doker/pharos.git
cd pharos
```

- Install Dependency

```bash
npm install
```

- Setup config in .env

```bash
nano .env
```

- Setup input value

* proxy: http://user:pass@ip:port

```bash
nano proxy.txt
```

- privatekey: how to get => join my channel: https://t.me/airdrophuntersieutoc

```bash
nano privateKeys.txt
```

- Run the script

```bash
node main.js
```
